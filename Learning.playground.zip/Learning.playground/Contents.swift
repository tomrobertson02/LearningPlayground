//: Playground - noun: a place where people can play

import UIKit

let a = 22
let b = 33
if a == 3 && b == 9 {
    print ("Pass!")
}
else if a == 4 && b == 10 {
    print ("Nearly")
}
else {
    print ("Fail")
}
