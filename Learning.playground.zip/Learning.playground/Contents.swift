//: Playground - noun: a place where people can play

import UIKit

var someCharacter:Character = "c"

switch someCharacter {
    
    case "a":
        print("is an A")
    case "b":
        print("is a B")
    default:
        print("default")
    
    
}
