//: Playground - noun: a place where people can play

import UIKit

let name = ("Wrong")
if name == ("Tom") {
    print ("Hi Tom")
} else {
    print ("Sorry, I don't know your name")
}
